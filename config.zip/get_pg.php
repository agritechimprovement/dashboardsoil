<?php
require_once 'config.php';

$iddevice = $_GET['iddevice'] ?? '';
$lokasi = $_GET['lokasi']