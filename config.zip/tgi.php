<?php
require_once 'config.php';

// Helper functions
function getFilteredData($iddevice = null, $lokasi = null, $pg = null) {
    global $conn;
    
    $sql = "SELECT * FROM tgi WHERE 1=1";
    
    if ($iddevice) {
        $sql .= " AND iddevice = '$iddevice'";
    }
    if ($lokasi) {
        $sql .= " AND lokasi = '$lokasi'";
    }
    if ($pg) {
        $sql .= " AND pg = '$pg'";
    }
    
    $sql .= " ORDER BY transid, date, time";
    
    $result = $conn->query($sql);
    $data = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

function getDevices($lokasi = null, $pg = null) {
    global $conn;
    $sql = "SELECT DISTINCT iddevice FROM tgi WHERE 1=1";
    if ($lokasi) {
        $sql .= " AND lokasi = '$lokasi'";
    }
    if ($pg) {
        $sql .= " AND pg = '$pg'";
    }
    $sql .= " ORDER BY iddevice";
    
    $result = $conn->query($sql);
    $values = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_array()) {
            $values[] = $row[0];
        }
    }
    
    return $values;
}

function getLocations($iddevice = null, $pg = null) {
    global $conn;
    $sql = "SELECT DISTINCT lokasi FROM tgi WHERE 1=1";
    if ($iddevice) {
        $sql .= " AND iddevice = '$iddevice'";
    }
    if ($pg) {
        $sql .= " AND pg = '$pg'";
    }
    $sql .= " ORDER BY lokasi";
    
    $result = $conn->query($sql);
    $values = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_array()) {
            $values[] = $row[0];
        }
    }
    
    return $values;
}

function getPGs($iddevice = null, $lokasi = null) {
    global $conn;
    $sql = "SELECT DISTINCT pg FROM tgi WHERE 1=1";
    if ($iddevice) {
        $sql .= " AND iddevice = '$iddevice'";
    }
    if ($lokasi) {
        $sql .= " AND lokasi = '$lokasi'";
    }
    $sql .= " ORDER BY pg";
    
    $result = $conn->query($sql);
    $values = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_array()) {
            $values[] = $row[0];
        }
    }
    
    return $values;
}

// Get filter values from URL
$iddevice = $_GET['iddevice'] ?? null;
$lokasi = $_GET['lokasi'] ?? null;
$pg = $_GET['pg'] ?? null;
$layout = $_GET['layout'] ?? 'side'; // side or vertical

// Get all filter options
$devices = getDevices($lokasi, $pg);
$locations = getLocations($iddevice, $pg);
$pgs = getPGs($iddevice, $lokasi);

// Get filtered data
$data = getFilteredData($iddevice, $lokasi, $pg);
$latestData = end($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TGI</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBGdfO4xZcU_rGZIowCN_2NB9UVqewGl5Y"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8">Tracking Gun Irrigation Dashboard</h1>
        
        <!-- Filters -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 bg-white p-4 rounded-lg shadow">
            <form id="filterForm" class="flex flex-wrap gap-4 col-span-3">
                <select name="iddevice" id="iddevice" class="p-2 border rounded">
                    <option value="">Select Device</option>
                    <?php foreach($devices as $device): ?>
                        <option value="<?= htmlspecialchars($device) ?>" 
                                <?= $iddevice === $device ? 'selected' : '' ?>>
                            <?= htmlspecialchars($device) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="lokasi" id="lokasi" class="p-2 border rounded">
                    <option value="">Select Location</option>
                    <?php foreach($locations as $loc): ?>
                        <option value="<?= htmlspecialchars($loc) ?>"
                                <?= $lokasi === $loc ? 'selected' : '' ?>>
                            <?= htmlspecialchars($loc) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="pg" id="pg" class="p-2 border rounded">
                    <option value="">Select PG</option>
                    <?php foreach($pgs as $pg_val): ?>
                        <option value="<?= htmlspecialchars($pg_val) ?>"
                                <?= $pg === $pg_val ? 'selected' : '' ?>>
                            <?= htmlspecialchars($pg_val) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            <div class="flex justify-end items-center">
                <select name="layout" id="layout" class="p-2 border rounded" onchange="updateLayout(this.value)">
                    <option value="side" <?= $layout === 'side' ? 'selected' : '' ?>>Side by Side</option>
                    <option value="vertical" <?= $layout === 'vertical' ? 'selected' : '' ?>>Vertical</option>
                </select>
            </div>
        </div>

        <?php if ($iddevice || $lokasi && !empty($data)): ?>
        <!-- Latest Metrics -->
        <!-- <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">Latest Pressure</h3>
                <p class="text-3xl font-bold">
                    <?= $latestData['pressure'] ?? '0' ?> bar
                </p>
                <p class="text-sm text-gray-600 mt-2">
                    Last updated: <?= $latestData['date'] ?? '' ?> <?= $latestData['time'] ?? '' ?>
                </p>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">Latest Speed</h3>
                <p class="text-3xl font-bold">
                    <?= $latestData['kecepatan'] ?? '0' ?> m/s
                </p>
                <p class="text-sm text-gray-600 mt-2">
                    Last updated: <?= $latestData['date'] ?? '' ?> <?= $latestData['time'] ?? '' ?>
                </p>
            </div>
        </div> -->

        <!-- Map and Charts -->
        <div id="visualizations" class="<?= $layout === 'side' ? 'grid grid-cols-1 lg:grid-cols-2 gap-6' : 'space-y-6' ?>">
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Device Path</h3>
                <div id="map" style="height: 400px;"></div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Metrics Over Time</h3>
                <canvas id="metricsChart"></canvas>
            </div>
        </div>

        <!-- Data Table -->
        <div class="mt-8 bg-white p-4 rounded-lg shadow overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Recent Data</h3>

            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Device</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pressure</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Speed</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach((array_reverse($data)) as $row): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['date']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['time']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['iddevice']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['pressure']) ?> bar</td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['kecepatan']) ?> m/s</td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($row['lokasi']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-8" role="alert">
        <p class="font-bold">Perhatian</p>
        <p>Silakan pilih Device dan Lokasi untuk menampilkan data.</p>
    </div>
        <?php endif; ?>
    </div>

    <script>
        // Handle filter changes
        ['iddevice', 'lokasi', 'pg'].forEach(filterId => {
            document.getElementById(filterId).addEventListener('change', function() {
                document.getElementById('filterForm').submit();
            });
        });

        function updateLayout(layout) {
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('layout', layout);
            window.location.href = currentUrl.toString();
        }

        <?php if (!empty($data)): ?>
        // Initialize Google Maps
        const mapData = <?= json_encode($data) ?>;
        const map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,  // Sesuaikan dengan kebutuhan
            center: {
                lat: parseFloat(mapData[0].latitude),
                lng: parseFloat(mapData[0].longitude)
            },
            mapTypeId: 'satellite',
            mapTypeControl: true,  // Menampilkan control untuk ganti tipe map
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                position: google.maps.ControlPosition.TOP_RIGHT
            }
        });

        // Process data into segments (split by speed = 0)
        let segments = [];
        let currentSegment = [];
        
        mapData.forEach((point, index) => {
            if (parseFloat(point.kecepatan) === 0) {
                if (currentSegment.length > 0) {
                    segments.push(currentSegment);
                    currentSegment = [];
                }
            }
            currentSegment.push(point);
            
            // Add marker with info window for each point
            const position = {
                lat: parseFloat(point.latitude),
                lng: parseFloat(point.longitude)
            };
            
            const marker = new google.maps.Marker({
                position: position,
                map: map,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 4,
                    fillColor: "#00FF00",
                    fillOpacity: 1,
                    strokeWeight: 0
                }
            });

            const infoWindow = new google.maps.InfoWindow({
                content: `
                    <div>
                        <p><strong>Speed:</strong> ${point.kecepatan} m/s</p>
                        <p><strong>Pressure:</strong> ${point.pressure} bar</p>
                        <p><strong>Date:</strong> ${point.date}</p>
                        <p><strong>Time:</strong> ${point.time}</p>
                    </div>
                `
            });

            marker.addListener('mouseover', () => {
                infoWindow.open(map, marker);
            });

            marker.addListener('mouseout', () => {
                infoWindow.close();
            });
        });

        // If there's a remaining segment, add it
        if (currentSegment.length > 0) {
            segments.push(currentSegment);
        }

        // Draw paths for each segment
        segments.forEach(segment => {
            const coordinates = segment.map(point => ({
                lat: parseFloat(point.latitude),
                lng: parseFloat(point.longitude)
            }));

            const path = new google.maps.Polyline({
                path: coordinates,
                geodesic: true,
                strokeColor: '#0000FF',
                strokeOpacity: 1.0,
                strokeWeight: 4
            });
            path.setMap(map);
        });

        // Initialize metrics chart
        const ctx = document.getElementById('metricsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: mapData.map(point => point.time),
                datasets: [{
                    label: 'Pressure (bar)',
                    data: mapData.map(point => point.pressure),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }, {
                    label: 'Speed (m/s)',
                    data: mapData.map(point => point.kecepatan),
                    borderColor: 'rgb(255, 99, 132)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>