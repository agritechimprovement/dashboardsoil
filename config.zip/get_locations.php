<?php
require_once 'config.php';

$iddevice = $_GET['iddevice'] ?? '';

if ($iddevice) {
    $sql = "SELECT DISTINCT lokasi FROM tgi WHERE iddevice = '$iddevice' ORDER BY lokasi";
    $result = $conn->query($sql);
    $locations = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_array()) {
            $locations[] = $row[0];
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($locations);
}
?>